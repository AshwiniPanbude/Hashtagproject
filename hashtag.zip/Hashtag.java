package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Hashtag {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Driver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		
		driver.findElement(By.name("name")).sendKeys("Ashwini Panbude");
		
		
	    driver.findElement(By.name("email")).sendKeys("ashwinipanbude@gmail.com");
		
		
		driver.findElement(By.name("phone")).sendKeys("9834765224");
		

		driver.findElement(By.xpath("//input[@id='inputFile']"))
				.sendKeys("C:\\Users\\HP\\Dekstop\\Ashwini_Panbude.pdf");
		
		 
		driver.findElement(By.name("description")).sendKeys("Abcd test");
		
		driver.findElement(By.name("btn")).click();
	}

}
